#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import numpy as np
import cv2
import rclpy

from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image


class RGBFrameSaver(Node):

    def __init__(self):
        super().__init__('rgb_frame_saver')

        self.saved = False

        self.sub = self.create_subscription(
            Image,
            '/camera/color/image_raw',
            self.callback,
            qos_profile_sensor_data
        )

        print("Waiting for RGB frame...")

    def callback(self, msg):

        if self.saved:
            return

        h = msg.height
        w = msg.width

        if msg.encoding == 'rgb8':

            rgb = np.ndarray(
                (h, w, 3),
                dtype=np.uint8,
                buffer=msg.data,
                strides=(msg.step, 3, 1)
            )

            image = cv2.cvtColor(
                rgb,
                cv2.COLOR_RGB2BGR
            )

        elif msg.encoding == 'bgr8':

            image = np.ndarray(
                (h, w, 3),
                dtype=np.uint8,
                buffer=msg.data,
                strides=(msg.step, 3, 1)
            ).copy()

        else:
            print("Unsupported encoding:", msg.encoding)
            return

        path = '/data/linaro/astra_foxy_ws/camera_rgb_test.jpg'

        if cv2.imwrite(path, image):

            print("RGB IMAGE SAVED:", path)
            print("Resolution:", w, "x", h)

            self.saved = True


def main():

    rclpy.init()

    node = RGBFrameSaver()

    deadline = time.monotonic() + 15

    try:

        while (
            rclpy.ok()
            and not node.saved
            and time.monotonic() < deadline
        ):
            rclpy.spin_once(
                node,
                timeout_sec=0.5
            )

        if not node.saved:
            print("ERROR: RGB frame timeout")

    finally:

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
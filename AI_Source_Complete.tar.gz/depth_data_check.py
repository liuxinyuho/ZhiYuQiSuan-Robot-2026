#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
import struct
import math
import statistics
import time

from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image


class DepthDataCheck(Node):

    def __init__(self):
        super().__init__('depth_data_check')

        self.received = False

        self.subscription = self.create_subscription(
            Image,
            '/camera/depth/image_raw',
            self.depth_callback,
            qos_profile_sensor_data
        )

        self.get_logger().info(
            'Waiting for Astra depth image...'
        )

    def depth_callback(self, msg):

        if self.received:
            return

        self.received = True

        raw = bytes(msg.data)

        print("\n========== ASTRA DEPTH DATA ==========")

        print("Width:", msg.width)
        print("Height:", msg.height)
        print("Encoding:", msg.encoding)
        print("Step:", msg.step)
        print("Big Endian:", msg.is_bigendian)
        print("Data Length:", len(raw))

        cx = msg.width // 2
        cy = msg.height // 2

        values = []

        if msg.encoding in ('16UC1', 'mono16'):

            endian = '>' if msg.is_bigendian else '<'

            print("\n========== CENTER 5x5 ==========")

            for y in range(max(0, cy - 2),
                           min(msg.height, cy + 3)):

                row = []

                for x in range(max(0, cx - 2),
                               min(msg.width, cx + 3)):

                    offset = y * msg.step + x * 2

                    value = struct.unpack_from(
                        endian + 'H',
                        raw,
                        offset
                    )[0]

                    row.append(value)

                    if value != 0 and value != 65535:
                        values.append(value)

                print(row)

            if values:

                median_value = statistics.median(values)

                print("\nValid depth pixels:", len(values))
                print("Median raw depth:", median_value)

                if msg.encoding == '16UC1':
                    print(
                        "If using the camera's 1mm depth format, "
                        "distance =",
                        median_value,
                        "mm"
                    )

            else:
                print("No valid depth values in center region.")

        elif msg.encoding == '32FC1':

            endian = '>' if msg.is_bigendian else '<'

            for y in range(max(0, cy - 2),
                           min(msg.height, cy + 3)):

                for x in range(max(0, cx - 2),
                               min(msg.width, cx + 3)):

                    offset = y * msg.step + x * 4

                    value = struct.unpack_from(
                        endian + 'f',
                        raw,
                        offset
                    )[0]

                    if math.isfinite(value) and value > 0:
                        values.append(value)

            if values:
                print(
                    "Center median raw depth:",
                    statistics.median(values)
                )

        else:
            print("Unsupported encoding:", msg.encoding)

        print("\n========== CHECK FINISHED ==========")


def main():

    rclpy.init()

    node = DepthDataCheck()

    deadline = time.monotonic() + 15

    try:

        while (
            rclpy.ok()
            and not node.received
            and time.monotonic() < deadline
        ):
            rclpy.spin_once(
                node,
                timeout_sec=1.0
            )

        if not node.received:
            print("ERROR: No depth frame received.")

    finally:

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
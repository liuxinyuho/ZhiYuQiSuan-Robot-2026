#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import numpy as np
import rclpy

from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image


class DepthStabilityCheck(Node):

    def __init__(self):

        super().__init__('depth_stability_check')

        self.frame_count = 0
        self.sample_count = 0
        self.max_samples = 12

        self.subscription = self.create_subscription(
            Image,
            '/camera/depth/image_raw',
            self.depth_callback,
            qos_profile_sensor_data
        )

        print("\n========== ASTRA DEPTH STABILITY TEST ==========")
        print("Waiting for depth frames...")
        print("Target samples:", self.max_samples)

    def depth_callback(self, msg):

        self.frame_count += 1

        if self.sample_count >= self.max_samples:
            return

        # 每15帧采样一次，降低CPU负担
        if self.frame_count % 15 != 0:
            return

        if msg.encoding != '16UC1':
            print("Unsupported encoding:", msg.encoding)
            return

        if msg.step < msg.width * 2:
            print("ERROR: Invalid image step")
            return

        if len(msg.data) < msg.step * msg.height:
            print("ERROR: Incomplete image data")
            return

        endian = '>' if msg.is_bigendian else '<'

        depth = np.ndarray(
            shape=(msg.height, msg.width),
            dtype=np.dtype(endian + 'u2'),
            buffer=msg.data,
            strides=(msg.step, 2)
        )

        # 有效深度区域
        valid = (depth > 0) & (depth < 65535)

        total_pixels = depth.size

        valid_pixels = np.count_nonzero(valid)

        full_ratio = (
            valid_pixels / total_pixels * 100.0
        )

        # 中心40x40区域
        cx = msg.width // 2
        cy = msg.height // 2

        center = depth[
            max(0, cy - 20):min(msg.height, cy + 20),
            max(0, cx - 20):min(msg.width, cx + 20)
        ]

        center_valid = (
            (center > 0) & (center < 65535)
        )

        center_count = np.count_nonzero(center_valid)

        center_total = center.size

        center_ratio = (
            center_count / center_total * 100.0
        )

        # 统计深度中位数
        if valid_pixels > 0:
            full_median = np.median(depth[valid])
        else:
            full_median = None

        if center_count > 0:
            center_median = np.median(
                center[center_valid]
            )
        else:
            center_median = None

        self.sample_count += 1

        print("\n========== SAMPLE", self.sample_count, "==========")

        print("Resolution:",
              msg.width, "x", msg.height)

        print("Encoding:", msg.encoding)

        print("Full valid pixels:",
              valid_pixels, "/", total_pixels)

        print("Full valid ratio: %.2f%%" % full_ratio)

        print("Center valid pixels:",
              center_count, "/", center_total)

        print("Center valid ratio: %.2f%%" % center_ratio)

        if full_median is not None:
            print("Full median depth: %.1f mm" % full_median)
        else:
            print("Full median depth: INVALID")

        if center_median is not None:
            print("Center median depth: %.1f mm" % center_median)
        else:
            print("Center median depth: INVALID")

        if center_count == 0:
            print("WARNING: Center depth invalid!")

        if valid_pixels == 0:
            print("WARNING: Entire depth image invalid!")

        print("====================================")

    def finished(self):
        return self.sample_count >= self.max_samples


def main():

    rclpy.init()

    node = DepthStabilityCheck()

    deadline = time.monotonic() + 20

    try:

        while (
            rclpy.ok()
            and not node.finished()
            and time.monotonic() < deadline
        ):

            rclpy.spin_once(
                node,
                timeout_sec=0.5
            )

        if not node.finished():
            print("\nWARNING: Sampling timeout!")

        print("\n========== TEST SUMMARY ==========")
        print("Received samples:", node.sample_count)

    finally:

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
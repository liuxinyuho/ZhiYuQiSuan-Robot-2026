
#!/usr/bin/env python3
# BM1684 ROS2 Foxy
# Astra S RGB + registered Depth + YOLOv8 BModel
# Independent demo: does not modify original AI scripts.

import json
import os
import time
from collections import deque

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String
import sophon.sail as sail

MODEL = '/home/linaro/bm1684_ai/red_flame_bm1684_f32.bmodel'
COLOR_TOPIC = '/camera/color/image_raw'
DEPTH_TOPIC = '/camera/depth/image_raw'
INFO_TOPIC = '/camera/color/camera_info'
RESULT_TOPIC = '/ai/fire_depth_result'
ANNOTATED_TOPIC = '/ai/fire_annotated'

CONFIDENCE = 0.45
NMS_IOU = 0.45
MAX_TIME_DIFF_MS = 50.0
INFER_PERIOD_SEC = 0.35


def stamp_ns(header):
    return header.stamp.sec * 1000000000 + header.stamp.nanosec


def letterbox(bgr, ih, iw):
    h, w = bgr.shape[:2]
    ratio = min(iw / float(w), ih / float(h))
    nw, nh = round(w * ratio), round(h * ratio)

    left = (iw - nw) // 2
    top = (ih - nh) // 2

    dst = np.full((ih, iw, 3), 114, dtype=np.uint8)
    dst[top:top + nh, left:left + nw] = cv2.resize(
        bgr, (nw, nh)
    )

    rgb = cv2.cvtColor(dst, cv2.COLOR_BGR2RGB)
    tensor = np.ascontiguousarray(
        rgb.transpose(2, 0, 1)[None],
        dtype=np.float32
    )
    tensor *= (1.0 / 255.0)

    return tensor, ratio, left, top


def decode(output, ratio, left, top, image_w, image_h):
    pred = np.asarray(output, dtype=np.float32)

    if pred.shape != (1, 6, 8400):
        raise ValueError(
            'Unexpected model output shape: %s' % (pred.shape,)
        )

    pred = pred[0]
    class_scores = pred[4:6]
    safe_scores = np.where(
        np.isfinite(class_scores),
        class_scores,
        -np.inf
    )

    classes = np.argmax(safe_scores, axis=0)
    scores = safe_scores[classes, np.arange(8400)]

    valid = (
        (scores >= CONFIDENCE)
        & np.all(np.isfinite(pred[:4]), axis=0)
    )
    valid &= (pred[2] > 0) & (pred[3] > 0)

    ids = np.flatnonzero(valid)

    if not ids.size:
        return []

    ids = ids[np.argsort(scores[ids])[::-1]][:200]
    xywh = pred[:4, ids].T

    boxes = np.column_stack((
        xywh[:, 0] - xywh[:, 2] / 2,
        xywh[:, 1] - xywh[:, 3] / 2,
        xywh[:, 0] + xywh[:, 2] / 2,
        xywh[:, 1] + xywh[:, 3] / 2
    ))

    cs, ss = classes[ids], scores[ids]
    selected = []

    for c in (0, 1):
        remaining = np.flatnonzero(cs == c)

        while remaining.size and len(selected) < 20:
            best = int(remaining[0])
            selected.append(best)

            rest = remaining[1:]

            if not rest.size:
                break

            b = boxes[best]
            br = boxes[rest]

            inter = (
                np.maximum(
                    0,
                    np.minimum(b[2], br[:, 2])
                    - np.maximum(b[0], br[:, 0])
                )
                * np.maximum(
                    0,
                    np.minimum(b[3], br[:, 3])
                    - np.maximum(b[1], br[:, 1])
                )
            )

            area_b = (
                max(0, b[2] - b[0])
                * max(0, b[3] - b[1])
            )

            area_r = (
                np.maximum(0, br[:, 2] - br[:, 0])
                * np.maximum(0, br[:, 3] - br[:, 1])
            )

            iou = inter / (
                area_b + area_r - inter + 1e-9
            )

            remaining = rest[iou <= NMS_IOU]

    selected.sort(
        key=lambda i: float(ss[i]),
        reverse=True
    )

    detections = []

    for i in selected[:20]:
        x1, y1, x2, y2 = boxes[i]

        x1 = int(np.clip(
            round((x1 - left) / ratio), 0, image_w - 1
        ))
        x2 = int(np.clip(
            round((x2 - left) / ratio), 0, image_w - 1
        ))
        y1 = int(np.clip(
            round((y1 - top) / ratio), 0, image_h - 1
        ))
        y2 = int(np.clip(
            round((y2 - top) / ratio), 0, image_h - 1
        ))

        if x2 <= x1 or y2 <= y1:
            continue

        detections.append({
            'class_id': int(cs[i]),
            'score': round(float(ss[i]), 3),
            'xyxy': [x1, y1, x2, y2]
        })

    return detections


def bgr_from_ros(msg):
    if (
        msg.encoding.lower() not in ('rgb8', 'bgr8')
        or msg.step < msg.width * 3
    ):
        raise ValueError(
            'Unsupported color encoding/step: %s'
            % msg.encoding
        )

    buf = np.frombuffer(msg.data, dtype=np.uint8)

    if buf.size < msg.step * msg.height:
        raise ValueError('Incomplete RGB image')

    frame = buf[:msg.step * msg.height]
    frame = frame.reshape((msg.height, msg.step))
    frame = frame[:, :msg.width * 3]
    frame = frame.reshape(
        (msg.height, msg.width, 3)
    )

    if msg.encoding.lower() == 'rgb8':
        return cv2.cvtColor(
            frame, cv2.COLOR_RGB2BGR
        )

    return frame.copy()


def depth_from_ros(msg):
    if (
        msg.encoding.lower() != '16uc1'
        or msg.step % 2
    ):
        raise ValueError(
            'Expected depth 16UC1, got: %s'
            % msg.encoding
        )

    dtype = np.dtype(
        '>u2' if msg.is_bigendian else '<u2'
    )
    count = (msg.step // 2) * msg.height

    buf = np.frombuffer(
        msg.data,
        dtype=dtype,
        count=count
    )

    return buf.reshape(
        (msg.height, msg.step // 2)
    )[:, :msg.width]


def sample_depth(depth, det, info):
    x1, y1, x2, y2 = det['xyxy']

    cx = (x1 + x2) / 2.0
    cy = (y1 + y2) / 2.0

    # Inner 60% of detection box
    half_w = max(
        2, int((x2 - x1) * 0.30)
    )
    half_h = max(
        2, int((y2 - y1) * 0.30)
    )

    xa = max(0, int(cx) - half_w)
    xb = min(
        depth.shape[1],
        int(cx) + half_w + 1
    )
    ya = max(0, int(cy) - half_h)
    yb = min(
        depth.shape[0],
        int(cy) + half_h + 1
    )

    roi = depth[ya:yb, xa:xb]

    if not roi.size:
        return {
            'depth_status': 'UNKNOWN',
            'reason': 'EMPTY_ROI'
        }

    # Valid test range in millimeters
    vals = roi[
        (roi >= 300) & (roi <= 8000)
    ]

    fraction = float(vals.size) / float(roi.size)

    base = {
        'valid_pixels': int(vals.size),
        'roi_pixels': int(roi.size),
        'valid_fraction': round(fraction, 3)
    }

    if vals.size < 15 or fraction < 0.10:
        return dict(
            base,
            depth_status='UNKNOWN',
            reason='NOT_ENOUGH_VALID_DEPTH'
        )

    p10, p90 = np.percentile(vals, [10, 90])

    if float(p90 - p10) > 1200:
        return dict(
            base,
            depth_status='UNKNOWN',
            reason='MIXED_FOREGROUND_BACKGROUND'
        )

    z = float(np.median(vals)) * 0.001

    result = dict(
        base,
        depth_status='VALID',
        z_m=round(z, 3),
        distance_cm=round(z * 100.0, 1),
        depth_p10_m=round(
            float(p10) * 0.001, 3
        ),
        depth_p90_m=round(
            float(p90) * 0.001, 3
        )
    )

    if (
        info is not None
        and info.k[0] > 0
        and info.k[4] > 0
    ):
        x = (cx - info.k[2]) * z / info.k[0]
        y = (cy - info.k[5]) * z / info.k[4]

        result['xyz_camera_m'] = [
            round(x, 3),
            round(y, 3),
            round(z, 3)
        ]

    return result


class FusionNode(Node):
    def __init__(self):
        super().__init__(
            'sophon_astra_depth_fusion'
        )

        if not os.path.isfile(MODEL):
            raise FileNotFoundError(MODEL)

        # BM1684 verified mode
        self.engine = sail.Engine(
            MODEL, 0, sail.IOMode.SYSIO
        )

        self.graph = self.engine.get_graph_names()[0]
        self.input_name = self.engine.get_input_names(
            self.graph
        )[0]
        self.output_name = self.engine.get_output_names(
            self.graph
        )[0]

        shape = list(self.engine.get_input_shape(
            self.graph,
            self.input_name
        ))
        output_shape = list(
            self.engine.get_output_shape(
                self.graph,
                self.output_name
            )
        )

        if (
            shape != [1, 3, 640, 640]
            or output_shape != [1, 6, 8400]
        ):
            raise RuntimeError(
                'Unexpected model input/output: '
                '%s -> %s'
                % (shape, output_shape)
            )

        self.rgb = None
        self.rgb_stamp_processed = -1
        self.depths = deque(maxlen=12)
        self.info = None

        self.output = self.create_publisher(
            String, RESULT_TOPIC, 10
        )
        self.preview = self.create_publisher(
            Image, ANNOTATED_TOPIC, 1
        )

        self.create_subscription(
            Image,
            COLOR_TOPIC,
            self.on_rgb,
            qos_profile_sensor_data
        )
        self.create_subscription(
            Image,
            DEPTH_TOPIC,
            self.on_depth,
            qos_profile_sensor_data
        )
        self.create_subscription(
            CameraInfo,
            INFO_TOPIC,
            self.on_info,
            qos_profile_sensor_data
        )

        self.create_timer(
            INFER_PERIOD_SEC,
            self.on_timer
        )

        self.get_logger().info(
            'Sophon SYSIO loaded %s, '
            'input=%s, output=%s'
            % (MODEL, shape, output_shape)
        )
        self.get_logger().warn(
            'Class 0/1 mapping not independently verified. '
            'Depth is approximate.'
        )

    def on_rgb(self, msg):
        self.rgb = msg

    def on_depth(self, msg):
        self.depths.append((
            stamp_ns(msg.header), msg
        ))

    def on_info(self, msg):
        self.info = msg

    def on_timer(self):
        rgb = self.rgb

        if rgb is None:
            return

        t_rgb = stamp_ns(rgb.header)

        if (
            t_rgb <= 0
            or t_rgb == self.rgb_stamp_processed
        ):
            return

        self.rgb_stamp_processed = t_rgb
        t0 = time.monotonic()

        try:
            frame = bgr_from_ros(rgb)

            tensor, ratio, left, top = letterbox(
                frame, 640, 640
            )

            t_infer = time.monotonic()

            result = self.engine.process(
                self.graph,
                {self.input_name: tensor}
            )

            inference_ms = (
                time.monotonic() - t_infer
            ) * 1000

            dets = decode(
                result[self.output_name],
                ratio,
                left,
                top,
                rgb.width,
                rgb.height
            )

            closest = (
                min(
                    self.depths,
                    key=lambda x: abs(x[0] - t_rgb)
                )
                if self.depths
                else None
            )

            diff = (
                abs(closest[0] - t_rgb) / 1e6
                if closest and closest[0] > 0
                else None
            )

            dep = None

            if (
                diff is not None
                and diff <= MAX_TIME_DIFF_MS
            ):
                if (
                    closest[1].width == rgb.width
                    and closest[1].height == rgb.height
                ):
                    dep = depth_from_ros(closest[1])

            for det in dets:
                if dep is None:
                    det.update(
                        depth_status='UNKNOWN',
                        reason='NO_SYNCHRONIZED_DEPTH'
                    )
                else:
                    det.update(
                        sample_depth(dep, det, self.info)
                    )

            out = {
                'state': (
                    'DETECTED'
                    if dets
                    else 'NO_DETECTION'
                ),
                'class_mapping_verified': False,
                'rgb_stamp_ns': t_rgb,
                'depth_diff_ms': (
                    round(diff, 2)
                    if diff is not None
                    else None
                ),
                'depth_pair_valid': dep is not None,
                'detections': dets,
                'inference_ms': round(
                    inference_ms, 1
                ),
                'total_ms': round(
                    (time.monotonic() - t0) * 1000, 1
                )
            }

            self.publish_preview(
                rgb, frame, dets
            )

        except Exception as exc:
            self.get_logger().error(
                'Fusion error: %s' % exc
            )
            out = {
                'state': 'ERROR',
                'error': str(exc)
            }

        msg = String()
        msg.data = json.dumps(
            out,
            ensure_ascii=False,
            allow_nan=False
        )
        self.output.publish(msg)

        if out.get('state') == 'DETECTED':
            self.get_logger().info(
                'detections=%s, depth_diff_ms=%s'
                % (
                    len(dets),
                    out.get('depth_diff_ms')
                )
            )

    def publish_preview(self, rgb, frame, dets):
        display = frame.copy()

        for d in dets:
            x1, y1, x2, y2 = d['xyxy']

            cv2.rectangle(
                display,
                (x1, y1),
                (x2, y2),
                (0, 255, 255),
                2
            )

            if d.get('depth_status') == 'VALID':
                desc = (
                    'C%d %.2f %.1fcm'
                    % (
                        d['class_id'],
                        d['score'],
                        d['distance_cm']
                    )
                )
            else:
                desc = (
                    'C%d %.2f UNKNOWN'
                    % (d['class_id'], d['score'])
                )

            cv2.putText(
                display,
                desc,
                (x1, max(16, y1 - 4)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                (0, 0, 255),
                2
            )

        message = Image()
        message.header = rgb.header
        message.height, message.width = (
            display.shape[:2]
        )
        message.encoding = 'bgr8'
        message.is_bigendian = 0
        message.step = display.shape[1] * 3
        message.data = np.ascontiguousarray(
            display
        ).tobytes()

        self.preview.publish(message)


def main():
    rclpy.init()
    node = None

    try:
        node = FusionNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()

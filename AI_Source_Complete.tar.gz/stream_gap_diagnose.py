#!/usr/bin/env python3
# BM1684 / ROS2 Foxy
# Diagnose RGB, Depth and AI output interruptions.
# Read-only diagnostic; does not modify ROS nodes.

import time
import json
import statistics

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image
from std_msgs.msg import String

TEST_SECONDS = 90
GAP_LIMIT = 0.5


class StreamDiagnosis(Node):
    def __init__(self):
        super().__init__('astra_stream_gap_diagnosis')

        self.start = time.monotonic()

        self.stats = {}

        for name in ('RGB', 'Depth', 'Fusion'):
            self.stats[name] = {
                'count': 0,
                'last': None,
                'max_gap': 0.0,
                'long_gaps': 0,
                'gaps': [],
                'header_ns': None,
                'max_stamp_gap': 0.0
            }

        self.depth_pair_fail = 0
        self.fusion_errors = 0
        self.last_report = self.start

        self.create_subscription(
            Image,
            '/camera/color/image_raw',
            lambda msg: self.on_image('RGB', msg),
            qos_profile_sensor_data
        )

        self.create_subscription(
            Image,
            '/camera/depth/image_raw',
            lambda msg: self.on_image('Depth', msg),
            qos_profile_sensor_data
        )

        self.create_subscription(
            String,
            '/ai/fire_depth_result',
            self.on_fusion,
            10
        )

    def update(self, name, stamp=None):
        now = time.monotonic()
        s = self.stats[name]

        if s['last'] is not None:
            gap = now - s['last']
            s['gaps'].append(gap)
            s['max_gap'] = max(s['max_gap'], gap)

            if gap > GAP_LIMIT:
                s['long_gaps'] += 1
                print(
                    '[GAP] {} 接收中断 {:.3f}s'.format(
                        name, gap
                    ),
                    flush=True
                )

                if name == 'Fusion':
                    self.print_camera_ages(now)

        s['last'] = now
        s['count'] += 1

        if stamp is not None and stamp > 0:
            old = s['header_ns']

            if old is not None:
                stamp_gap = (stamp - old) / 1e9

                if stamp_gap > s['max_stamp_gap']:
                    s['max_stamp_gap'] = stamp_gap

                if stamp_gap > GAP_LIMIT:
                    print(
                        '[STAMP] {} 采集时间戳跳变 {:.3f}s'.format(
                            name, stamp_gap
                        ),
                        flush=True
                    )

            s['header_ns'] = stamp

    def print_camera_ages(self, now):
        for name in ('RGB', 'Depth'):
            last = self.stats[name]['last']

            if last is None:
                print('    {} 尚未接收'.format(name))
            else:
                age = now - last
                print(
                    '    {} 最近接收距今 {:.3f}s'.format(
                        name, age
                    )
                )

    def on_image(self, name, msg):
        stamp = (
            msg.header.stamp.sec * 1000000000
            + msg.header.stamp.nanosec
        )
        self.update(name, stamp)

    def on_fusion(self, msg):
        self.update('Fusion')

        try:
            result = json.loads(msg.data)

            if result.get('state') == 'ERROR':
                self.fusion_errors += 1
                print(
                    '[ERROR]',
                    result.get('error'),
                    flush=True
                )

            if result.get('depth_pair_valid') is False:
                self.depth_pair_fail += 1
                print(
                    '[DEPTH] {} | diff={}ms'.format(
                        result.get('depth_pair_reason'),
                        result.get('depth_diff_ms')
                    ),
                    flush=True
                )

        except Exception as exc:
            self.fusion_errors += 1
            print('[JSON ERROR]', exc)

    def report(self):
        now = time.monotonic()
        elapsed = now - self.start

        print(
            '\n========== {:.1f}s 诊断统计 =========='.format(
                elapsed
            )
        )

        for name in ('RGB', 'Depth', 'Fusion'):
            s = self.stats[name]

            print('\n{}:'.format(name))
            print('  消息数:', s['count'])
            print(
                '  平均频率: {:.2f} Hz'.format(
                    s['count'] / max(elapsed, 0.001)
                )
            )
            print(
                '  最大接收间隔: {:.1f} ms'.format(
                    s['max_gap'] * 1000
                )
            )
            print(
                '  超过500ms中断次数:',
                s['long_gaps']
            )

            if name != 'Fusion':
                print(
                    '  最大时间戳间隔: {:.1f} ms'.format(
                        s['max_stamp_gap'] * 1000
                    )
                )

            if s['gaps']:
                print(
                    '  接收间隔中位数: {:.1f} ms'.format(
                        statistics.median(s['gaps']) * 1000
                    )
                )

        print('\n深度匹配失败:', self.depth_pair_fail)
        print('融合错误:', self.fusion_errors)
        print('===================================', flush=True)


def main():
    rclpy.init()
    node = StreamDiagnosis()

    print('========== ASTRA 数据流定位测试 ==========')
    print('同时监测 RGB / Depth / Fusion')
    print('测试时长: {}秒'.format(TEST_SECONDS))
    print('无需移动相机或修改驱动', flush=True)

    try:
        while time.monotonic() - node.start < TEST_SECONDS:
            rclpy.spin_once(node, timeout_sec=0.1)

            now = time.monotonic()

            if now - node.last_report >= 15:
                node.last_report = now
                node.report()

        print('\n========== 最终结果 ==========')
        node.report()

    except KeyboardInterrupt:
        print('\n测试提前结束')
        node.report()

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()

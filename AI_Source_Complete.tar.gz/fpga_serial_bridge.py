#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import struct
import time
import serial
import rclpy

from rclpy.node import Node
from std_msgs.msg import String


class FPGASerialBridge(Node):

    def __init__(self):
        super().__init__('fpga_serial_bridge')

        # ==========================================
        # UART CONFIG
        # ==========================================

        self.port = '/dev/ttyUSB0'
        self.baudrate = 115200

        self.ser = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=0,
            write_timeout=0.5
        )

        self.rx_buffer = bytearray()

        self.frame_count = 0
        self.tx_count = 0

        self.latest_telemetry = None
        self.last_telemetry_time = 0.0

        # ==========================================
        # FPGA -> ROS2
        # ==========================================

        self.publisher = self.create_publisher(
            String,
            '/fpga/telemetry',
            10
        )

        # ==========================================
        # ROS2 -> FPGA
        # ==========================================

        self.command_subscriber = self.create_subscription(
            String,
            '/fpga/command',
            self.command_callback,
            10
        )

        # ==========================================
        # UART RX TIMER
        # ==========================================

        self.timer = self.create_timer(
            0.01,
            self.read_serial
        )

        self.get_logger().info(
            'FPGA UART BRIDGE STARTED'
        )

        self.get_logger().info(
            'Serial: /dev/ttyUSB0 115200 8N1'
        )

        self.get_logger().info(
            'Publishing: /fpga/telemetry'
        )

        self.get_logger().info(
            'Subscribed: /fpga/command'
        )

        self.get_logger().info(
            'Keyboard control: ENABLED'
        )

    # ==============================================
    # BUILD UART FRAME
    # ==============================================

    @staticmethod
    def build_frame(cmd, payload=b''):

        payload = bytes(payload)

        length = len(payload)

        if length > 16:
            raise ValueError('Payload too long')

        checksum = (
            cmd + length + sum(payload)
        ) & 0xFF

        frame = (
            bytes([0xAA, 0x55, cmd, length])
            + payload
            + bytes([checksum])
        )

        return frame

    # ==============================================
    # SEND UART FRAME
    # ==============================================

    def send_frame(self, cmd, payload=b''):

        if not self.ser.is_open:

            self.get_logger().error(
                'UART is not open'
            )

            return False

        try:

            frame = self.build_frame(
                cmd,
                payload
            )

            written = self.ser.write(frame)

            self.ser.flush()

            if written != len(frame):

                self.get_logger().error(
                    'UART partial write'
                )

                return False

            self.tx_count += 1

            self.get_logger().info(
                'UART TX CMD=0x%02X DATA=%s FRAME=%s'
                % (
                    cmd,
                    payload.hex(' '),
                    frame.hex(' ')
                )
            )

            return True

        except Exception as e:

            self.get_logger().error(
                'UART TX ERROR: %s' % e
            )

            return False

    # ==============================================
    # ROS2 COMMAND CALLBACK
    # ==============================================

    def command_callback(self, msg):

        try:

            command_data = json.loads(msg.data)

        except Exception as e:

            self.get_logger().error(
                'Invalid command JSON: %s' % e
            )

            return

        if not isinstance(command_data, dict):

            self.get_logger().error(
                'Command must be a JSON object'
            )

            return

        command = str(
            command_data.get('cmd', '')
        ).upper().strip()

        # ==========================================
        # AI ON
        # ==========================================

        if command == 'AI_ON':

            self.send_frame(
                0x02,
                bytes([0x01])
            )

        # ==========================================
        # AI OFF
        # ==========================================

        elif command == 'AI_OFF':

            self.send_frame(
                0x02,
                bytes([0x00])
            )

        # ==========================================
        # STOP
        # ==========================================

        elif command == 'STOP':

            self.send_frame(
                0x03,
                b''
            )

        # ==========================================
        # START WAYPOINT
        # ==========================================

        elif command == 'WAYPOINT_START':

            self.send_frame(
                0x04,
                b''
            )

        # ==========================================
        # VELOCITY
        #
        # CMD = 0x01
        # LEN = 6
        #
        # VX: signed 16bit little-endian
        # VY: signed 16bit little-endian
        # WZ: signed 16bit little-endian
        #
        # FPGA limits:
        # VX +/-24
        # VY +/-24
        # WZ +/-12
        # ==========================================

        elif command == 'VELOCITY':

            # --------------------------------------
            # 1. 检查遥测是否正常
            # --------------------------------------

            if (
                self.latest_telemetry is None
                or time.monotonic()
                - self.last_telemetry_time > 0.5
            ):

                self.get_logger().error(
                    'Velocity rejected: FPGA telemetry stale'
                )

                return

            # --------------------------------------
            # 2. 必须处于 HOST 模式
            # --------------------------------------

            if not self.latest_telemetry.get(
                'host_mode', False
            ):

                self.get_logger().error(
                    'Velocity rejected: FPGA not in HOST mode'
                )

                return

            # --------------------------------------
            # 3. 不再要求 AI_MODE = 1
            #
            # HOST=1、AI=0 时允许键盘运动
            # AI识别与人工键盘控制相互独立
            # --------------------------------------

            # --------------------------------------
            # 4. 读取速度参数
            # --------------------------------------

            try:

                vx = int(command_data['vx'])
                vy = int(command_data['vy'])
                wz = int(command_data['wz'])

            except Exception:

                self.get_logger().error(
                    'VELOCITY requires integer vx, vy, wz'
                )

                return

            # --------------------------------------
            # 5. VX 限制
            # --------------------------------------

            if not (-24 <= vx <= 24):

                self.get_logger().error(
                    'VX out of range: -24 ~ +24'
                )

                return

            # --------------------------------------
            # 6. VY 限制
            # --------------------------------------

            if not (-24 <= vy <= 24):

                self.get_logger().error(
                    'VY out of range: -24 ~ +24'
                )

                return

            # --------------------------------------
            # 7. WZ 限制
            # --------------------------------------

            if not (-12 <= wz <= 12):

                self.get_logger().error(
                    'WZ out of range: -12 ~ +12'
                )

                return

            # --------------------------------------
            # 8. 打包速度数据
            # --------------------------------------

            payload = struct.pack(
                '<hhh',
                vx,
                vy,
                wz
            )

            # --------------------------------------
            # 9. 发送 FPGA
            # --------------------------------------

            self.send_frame(
                0x01,
                payload
            )

        else:

            self.get_logger().warning(
                'Unknown FPGA command: %s' % command
            )

    # ==============================================
    # UART RECEIVE
    # ==============================================

    def read_serial(self):

        try:

            waiting = self.ser.in_waiting

            if waiting <= 0:
                return

            data = self.ser.read(waiting)

            self.rx_buffer.extend(data)

            self.parse_frames()

        except Exception as e:

            self.get_logger().error(
                'UART RX ERROR: %s' % e
            )

    # ==============================================
    # PARSE FPGA TELEMETRY
    # ==============================================

    def parse_frames(self):

        while True:

            start = self.rx_buffer.find(
                b'\xAA\x55'
            )

            if start < 0:

                if (
                    len(self.rx_buffer) > 0
                    and self.rx_buffer[-1] == 0xAA
                ):

                    self.rx_buffer[:] = b'\xAA'

                else:

                    self.rx_buffer.clear()

                return

            if start > 0:

                del self.rx_buffer[:start]

            if len(self.rx_buffer) < 4:
                return

            cmd = self.rx_buffer[2]

            length = self.rx_buffer[3]

            if length > 32:

                del self.rx_buffer[0]

                continue

            total_length = length + 5

            if len(self.rx_buffer) < total_length:
                return

            frame = bytes(
                self.rx_buffer[:total_length]
            )

            del self.rx_buffer[:total_length]

            # Current telemetry protocol
            if cmd != 0x81 or length != 18:
                continue

            payload = frame[4:-1]

            # ======================================
            # PARSE DATA
            # ======================================

            x_mm = int.from_bytes(
                payload[0:4],
                'little',
                signed=True
            )

            y_mm = int.from_bytes(
                payload[4:8],
                'little',
                signed=True
            )

            yaw_cdeg = int.from_bytes(
                payload[8:12],
                'little',
                signed=True
            )

            ultrasonic_mm = int.from_bytes(
                payload[12:14],
                'little'
            )

            obstacle_state = payload[14]

            waypoint_index = payload[15]

            nav_state = payload[16]

            flags = payload[17]

            # ======================================
            # CHECKSUM
            # ======================================

            expected = sum(
                frame[2:-1]
            ) & 0xFF

            received = frame[-1]

            if received == expected:

                checksum_status = 'OK'

            elif (
                (flags & 0x02)
                and ((received + 2) & 0xFF) == expected
            ):

                checksum_status = 'KNOWN_TX_CHECKSUM_BUG'

            else:

                self.get_logger().warning(
                    'Invalid checksum: '
                    'received=0x%02X expected=0x%02X'
                    % (received, expected)
                )

                continue

            # ======================================
            # BUILD TELEMETRY
            # ======================================

            result = {

                'state': 'CONNECTED',

                'x_mm': x_mm,
                'y_mm': y_mm,
                'yaw_cdeg': yaw_cdeg,

                'x_m': x_mm / 1000.0,
                'y_m': y_mm / 1000.0,
                'yaw_deg': yaw_cdeg / 100.0,

                'ultrasonic_mm': ultrasonic_mm,
                'ultrasonic_m': ultrasonic_mm / 1000.0,

                'obstacle_state': obstacle_state,

                'waypoint_index': waypoint_index,

                'nav_state': nav_state,

                'ai_mode': bool(flags & 0x01),

                'host_mode': bool(flags & 0x02),

                'flags': flags,

                'checksum_status': checksum_status,

                'raw_frame': frame.hex(' ')
            }

            self.latest_telemetry = result

            self.last_telemetry_time = time.monotonic()

            msg = String()

            msg.data = json.dumps(
                result,
                ensure_ascii=False
            )

            self.publisher.publish(msg)

            self.frame_count += 1

            if self.frame_count % 10 == 0:

                self.get_logger().info(
                    'FPGA: X=%.3fm Y=%.3fm '
                    'Yaw=%.2fdeg Ultra=%dmm '
                    'AI=%d HOST=%d Frames=%d'
                    % (
                        result['x_m'],
                        result['y_m'],
                        result['yaw_deg'],
                        ultrasonic_mm,
                        result['ai_mode'],
                        result['host_mode'],
                        self.frame_count
                    )
                )

    # ==============================================
    # DESTROY
    # ==============================================

    def destroy_node(self):

        if hasattr(self, 'ser') and self.ser.is_open:

            self.ser.close()

        super().destroy_node()


# ==============================================
# MAIN
# ==============================================

def main(args=None):

    rclpy.init(args=args)

    node = None

    try:

        node = FPGASerialBridge()

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    except Exception as e:

        print('FPGA UART ERROR:', e)

    finally:

        if node is not None:

            node.destroy_node()

        if rclpy.ok():

            rclpy.shutdown()


if __name__ == '__main__':

    main()
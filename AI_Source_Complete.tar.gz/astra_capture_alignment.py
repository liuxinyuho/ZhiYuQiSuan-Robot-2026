#!/usr/bin/env python3
# ASTRA S RGB/Depth 空间配准可视化检查
# 仅使用 Python 标准库和已有 ROS 2 依赖

import os
import time
import zlib
import struct
import statistics
from pathlib import Path

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image

OUTPUT = Path("/data/linaro/astra_foxy_ws/registration_check")
MAX_TIME_DIFF_MS = 40.0


def timestamp_ns(msg):
    return msg.header.stamp.sec * 1000000000 + msg.header.stamp.nanosec


def png_chunk(tag, data):
    crc = zlib.crc32(tag + data) & 0xffffffff
    return (
        struct.pack(">I", len(data))
        + tag
        + data
        + struct.pack(">I", crc)
    )


def save_rgb_png(path, width, height, rows):
    raw = bytearray()

    for row in rows:
        if len(row) != width * 3:
            raise ValueError("PNG 行长度不正确")
        raw.append(0)
        raw.extend(row)

    header = struct.pack(
        ">IIBBBBB", width, height, 8, 2, 0, 0, 0
    )

    png = (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", header)
        + png_chunk(b"IDAT", zlib.compress(raw, 6))
        + png_chunk(b"IEND", b"")
    )

    path.write_bytes(png)


class AstraCapture(Node):
    def __init__(self):
        super().__init__("astra_alignment_capture")
        self.rgb = None
        self.depth = None
        self.pair = None
        self.best_diff = float("inf")

        self.create_subscription(
            Image,
            "/camera/color/image_raw",
            self.on_rgb,
            qos_profile_sensor_data
        )

        self.create_subscription(
            Image,
            "/camera/depth/image_raw",
            self.on_depth,
            qos_profile_sensor_data
        )

    def on_rgb(self, msg):
        self.rgb = msg
        self.try_match()

    def on_depth(self, msg):
        self.depth = msg
        self.try_match()

    def try_match(self):
        if self.pair is not None:
            return

        if self.rgb is None or self.depth is None:
            return

        t1 = timestamp_ns(self.rgb)
        t2 = timestamp_ns(self.depth)

        if not t1 or not t2:
            return

        diff = abs(t1 - t2) / 1000000.0
        self.best_diff = min(self.best_diff, diff)

        if diff <= MAX_TIME_DIFF_MS:
            self.pair = (self.rgb, self.depth, diff)


def depth_color(mm):
    if mm == 0:
        return (0, 0, 0)

    # 0.4~5米的伪彩色映射：近处偏红，远处偏蓝
    t = max(0.0, min(1.0, (mm - 400.0) / 4600.0))

    r = int(255 * (1.0 - t))
    g = int(220 * (1.0 - abs(2.0 * t - 1.0)))
    b = int(255 * t)

    return (r, g, b)


def generate_images(rgb, depth, diff):
    width = rgb.width
    height = rgb.height

    if width != depth.width or height != depth.height:
        raise RuntimeError("RGB与Depth分辨率不同，不能直接叠加")

    if rgb.encoding.lower() not in ("rgb8", "bgr8"):
        raise RuntimeError("不支持的RGB编码：" + rgb.encoding)

    if depth.encoding.lower() != "16uc1":
        raise RuntimeError("不支持的Depth编码：" + depth.encoding)

    OUTPUT.mkdir(parents=True, exist_ok=True)

    rgb_data = bytes(rgb.data)
    depth_data = bytes(depth.data)

    order = ">" if depth.is_bigendian else "<"
    depth_format = order + str(width) + "H"

    rgb_rows = []
    depth_rows = []
    overlay_rows = []
    comparison_rows = []

    valid_count = 0
    center_distances = []
    last_depth_row = None

    cx = width // 2
    cy = height // 2

    for y in range(height):
        # 读取彩色图像
        start = y * rgb.step
        color = bytearray(rgb_data[start:start + width * 3])

        if rgb.encoding.lower() == "bgr8":
            for x in range(width):
                i = x * 3
                color[i], color[i + 2] = color[i + 2], color[i]

        # 读取16位深度，单位毫米
        values = struct.unpack_from(
            depth_format, depth_data, y * depth.step
        )

        pseudo = bytearray(width * 3)
        overlay = bytearray(color)

        for x, mm in enumerate(values):
            i = x * 3

            if mm > 0:
                valid_count += 1

            if abs(x - cx) <= 5 and abs(y - cy) <= 5:
                if mm > 0:
                    center_distances.append(mm)

            r, g, b = depth_color(mm)
            pseudo[i:i + 3] = bytes((r, g, b))

            # 深度边缘标黄，用来和RGB物体轮廓比较
            edge = False

            if x > 0:
                left = values[x - 1]
                if (mm > 0) != (left > 0):
                    edge = True
                elif mm > 0 and left > 0:
                    edge = abs(mm - left) >= 150

            if last_depth_row is not None:
                above = last_depth_row[x]
                if (mm > 0) != (above > 0):
                    edge = True
                elif mm > 0 and above > 0:
                    edge = edge or abs(mm - above) >= 150

            if edge:
                overlay[i:i + 3] = b"\xff\xeb\x00"

        last_depth_row = values

        rgb_rows.append(bytes(color))
        depth_rows.append(bytes(pseudo))
        overlay_rows.append(bytes(overlay))

        # 从左到右：RGB / Depth / 深度边缘叠加
        comparison_rows.append(
            bytes(color) + bytes(pseudo) + bytes(overlay)
        )

    save_rgb_png(
        OUTPUT / "01_rgb.png", width, height, rgb_rows
    )
    save_rgb_png(
        OUTPUT / "02_depth.png", width, height, depth_rows
    )
    save_rgb_png(
        OUTPUT / "03_overlay.png", width, height, overlay_rows
    )
    save_rgb_png(
        OUTPUT / "04_comparison.png",
        width * 3, height, comparison_rows
    )

    print("\n========== 图像采集结果 ==========")
    print("RGB编码:", rgb.encoding)
    print("Depth编码:", depth.encoding)
    print("分辨率:", width, "x", height)
    print("RGB坐标系:", rgb.header.frame_id)
    print("Depth坐标系:", depth.header.frame_id)
    print("时间戳差: {:.2f} ms".format(diff))

    total = width * height
    print("有效深度像素: {}/{}".format(valid_count, total))
    print("有效深度比例: {:.1f}%".format(valid_count * 100 / total))

    if center_distances:
        distance = statistics.median(center_distances)
        print("中心距离: {:.1f} cm".format(distance / 10.0))
    else:
        print("中心距离: UNKNOWN")

    print("\n========== 保存的图片 ==========")
    for path in sorted(OUTPUT.glob("*.png")):
        print(path, "({} KB)".format(path.stat().st_size // 1024))

    print("\n========== ASTRA ALIGNMENT IMAGES SAVED ==========")


def main():
    rclpy.init()
    node = AstraCapture()

    print("正在等待RGB与Depth匹配图像...")
    print("最大时间戳差:", MAX_TIME_DIFF_MS, "ms", flush=True)

    pair = None

    try:
        deadline = time.monotonic() + 15

        while time.monotonic() < deadline:
            rclpy.spin_once(node, timeout_sec=0.2)

            if node.pair is not None:
                pair = node.pair
                break
    finally:
        node.destroy_node()
        rclpy.shutdown()

    if pair is None:
        print("未捕获到符合条件的RGB/Depth图像对")
        print("最小观测时间差:", node.best_diff, "ms")
        return

    generate_images(*pair)


if __name__ == "__main__":
    main()

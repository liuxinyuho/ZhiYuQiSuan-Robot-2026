
#!/usr/bin/env python3
# BM1684 / ROS2 Foxy / ASTRA S / YOLOv8
# V2: low-latency RGB+Depth fusion with stale-frame protection

import json
import os
import time
from collections import deque

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String

import sophon.sail as sail

MODEL = "/home/linaro/bm1684_ai/red_flame_bm1684_f32.bmodel"

COLOR_TOPIC = "/camera/color/image_raw"
DEPTH_TOPIC = "/camera/depth/image_raw"
INFO_TOPIC = "/camera/color/camera_info"

RESULT_TOPIC = "/ai/fire_depth_result"
ANNOTATED_TOPIC = "/ai/fire_annotated"

CONFIDENCE = 0.45
NMS_IOU = 0.45

MAX_TIME_DIFF_MS = 50.0
MAX_RECEIVE_AGE_MS = 300.0
MAX_RECEIVE_GAP_MS = 180.0

INFER_PERIOD_SEC = 0.25


def stamp_ns(header):
    return (
        header.stamp.sec * 1000000000
        + header.stamp.nanosec
    )


def letterbox(bgr, ih, iw):
    h, w = bgr.shape[:2]

    ratio = min(
        iw / float(w),
        ih / float(h)
    )

    nw = int(round(w * ratio))
    nh = int(round(h * ratio))

    left = (iw - nw) // 2
    top = (ih - nh) // 2

    dst = np.full(
        (ih, iw, 3),
        114,
        dtype=np.uint8
    )

    dst[
        top:top + nh,
        left:left + nw
    ] = cv2.resize(bgr, (nw, nh))

    rgb = cv2.cvtColor(
        dst,
        cv2.COLOR_BGR2RGB
    )

    tensor = np.ascontiguousarray(
        rgb.transpose(2, 0, 1)[None],
        dtype=np.float32
    )

    tensor *= 1.0 / 255.0

    return tensor, ratio, left, top


def decode(output, ratio, left, top, width, height):
    pred = np.asarray(
        output,
        dtype=np.float32
    )

    if pred.shape != (1, 6, 8400):
        raise ValueError(
            "Unexpected output shape: %s"
            % (pred.shape,)
        )

    pred = pred[0]
    scores_raw = pred[4:6]

    safe = np.where(
        np.isfinite(scores_raw),
        scores_raw,
        -np.inf
    )

    classes = np.argmax(safe, axis=0)

    scores = safe[
        classes,
        np.arange(8400)
    ]

    valid = scores >= CONFIDENCE
    valid &= np.all(
        np.isfinite(pred[:4]),
        axis=0
    )
    valid &= pred[2] > 0
    valid &= pred[3] > 0

    ids = np.flatnonzero(valid)

    if ids.size == 0:
        return []

    ids = ids[
        np.argsort(scores[ids])[::-1]
    ][:200]

    xywh = pred[:4, ids].T

    boxes = np.column_stack((
        xywh[:, 0] - xywh[:, 2] / 2,
        xywh[:, 1] - xywh[:, 3] / 2,
        xywh[:, 0] + xywh[:, 2] / 2,
        xywh[:, 1] + xywh[:, 3] / 2
    ))

    cls = classes[ids]
    conf = scores[ids]

    selected = []

    for class_id in (0, 1):
        remaining = np.flatnonzero(
            cls == class_id
        )

        while remaining.size and len(selected) < 20:
            best = int(remaining[0])
            selected.append(best)

            rest = remaining[1:]

            if rest.size == 0:
                break

            a = boxes[best]
            b = boxes[rest]

            intersection = (
                np.maximum(
                    0,
                    np.minimum(a[2], b[:, 2])
                    - np.maximum(a[0], b[:, 0])
                )
                * np.maximum(
                    0,
                    np.minimum(a[3], b[:, 3])
                    - np.maximum(a[1], b[:, 1])
                )
            )

            area_a = (
                max(0, a[2] - a[0])
                * max(0, a[3] - a[1])
            )

            area_b = (
                np.maximum(0, b[:, 2] - b[:, 0])
                * np.maximum(0, b[:, 3] - b[:, 1])
            )

            iou = intersection / (
                area_a + area_b - intersection + 1e-9
            )

            remaining = rest[
                iou <= NMS_IOU
            ]

    selected.sort(
        key=lambda i: float(conf[i]),
        reverse=True
    )

    detections = []

    for i in selected[:20]:
        x1, y1, x2, y2 = boxes[i]

        x1 = int(np.clip(
            round((x1 - left) / ratio),
            0,
            width - 1
        ))

        x2 = int(np.clip(
            round((x2 - left) / ratio),
            0,
            width - 1
        ))

        y1 = int(np.clip(
            round((y1 - top) / ratio),
            0,
            height - 1
        ))

        y2 = int(np.clip(
            round((y2 - top) / ratio),
            0,
            height - 1
        ))

        if x2 <= x1 or y2 <= y1:
            continue

        detections.append({
            "class_id": int(cls[i]),
            "score": round(float(conf[i]), 3),
            "xyxy": [x1, y1, x2, y2]
        })

    return detections


def bgr_from_ros(msg):
    encoding = msg.encoding.lower()

    if encoding not in ("rgb8", "bgr8"):
        raise ValueError(
            "Unsupported RGB encoding: "
            + msg.encoding
        )

    if msg.step < msg.width * 3:
        raise ValueError("Invalid RGB step")

    buf = np.frombuffer(
        msg.data,
        dtype=np.uint8
    )

    if buf.size < msg.step * msg.height:
        raise ValueError("Incomplete RGB frame")

    frame = buf[
        :msg.step * msg.height
    ].reshape(
        msg.height,
        msg.step
    )

    frame = frame[
        :,
        :msg.width * 3
    ].reshape(
        msg.height,
        msg.width,
        3
    )

    if encoding == "rgb8":
        return cv2.cvtColor(
            frame,
            cv2.COLOR_RGB2BGR
        )

    return frame.copy()


def depth_from_ros(msg):
    if msg.encoding.lower() != "16uc1":
        raise ValueError(
            "Unsupported depth encoding: "
            + msg.encoding
        )

    if msg.step % 2 != 0:
        raise ValueError("Invalid depth step")

    dtype = np.dtype(
        ">u2" if msg.is_bigendian else "<u2"
    )

    count = (
        msg.step // 2
    ) * msg.height

    buf = np.frombuffer(
        msg.data,
        dtype=dtype,
        count=count
    )

    return buf.reshape(
        msg.height,
        msg.step // 2
    )[:, :msg.width]


def sample_depth(depth, detection, camera_info):
    x1, y1, x2, y2 = detection["xyxy"]

    cx = (x1 + x2) / 2.0
    cy = (y1 + y2) / 2.0

    hw = max(
        2,
        int((x2 - x1) * 0.30)
    )

    hh = max(
        2,
        int((y2 - y1) * 0.30)
    )

    xa = max(0, int(cx) - hw)
    xb = min(depth.shape[1], int(cx) + hw + 1)

    ya = max(0, int(cy) - hh)
    yb = min(depth.shape[0], int(cy) + hh + 1)

    roi = depth[ya:yb, xa:xb]

    if roi.size == 0:
        return {
            "depth_status": "UNKNOWN",
            "reason": "EMPTY_ROI"
        }

    valid = roi[
        (roi >= 300) & (roi <= 8000)
    ]

    fraction = (
        float(valid.size) / float(roi.size)
    )

    details = {
        "valid_pixels": int(valid.size),
        "roi_pixels": int(roi.size),
        "valid_fraction": round(fraction, 3)
    }

    if valid.size < 15 or fraction < 0.10:
        return dict(
            details,
            depth_status="UNKNOWN",
            reason="NOT_ENOUGH_VALID_DEPTH"
        )

    p10, p90 = np.percentile(
        valid,
        [10, 90]
    )

    if p90 - p10 > 1200:
        return dict(
            details,
            depth_status="UNKNOWN",
            reason="MIXED_FOREGROUND_BACKGROUND"
        )

    z = float(np.median(valid)) * 0.001

    result = dict(
        details,
        depth_status="VALID",
        z_m=round(z, 3),
        distance_cm=round(z * 100.0, 1)
    )

    if (
        camera_info is not None
        and camera_info.k[0] > 0
        and camera_info.k[4] > 0
    ):
        x = (
            (cx - camera_info.k[2])
            * z / camera_info.k[0]
        )

        y = (
            (cy - camera_info.k[5])
            * z / camera_info.k[4]
        )

        result["xyz_camera_m"] = [
            round(x, 3),
            round(y, 3),
            round(z, 3)
        ]

    return result


class FusionNode(Node):
    def __init__(self):
        super().__init__(
            "sophon_astra_depth_fusion"
        )

        if not os.path.isfile(MODEL):
            raise FileNotFoundError(MODEL)

        self.engine = sail.Engine(
            MODEL,
            0,
            sail.IOMode.SYSIO
        )

        self.graph = self.engine.get_graph_names()[0]

        self.input_name = (
            self.engine.get_input_names(
                self.graph
            )[0]
        )

        self.output_name = (
            self.engine.get_output_names(
                self.graph
            )[0]
        )

        input_shape = list(
            self.engine.get_input_shape(
                self.graph,
                self.input_name
            )
        )

        output_shape = list(
            self.engine.get_output_shape(
                self.graph,
                self.output_name
            )
        )

        if (
            input_shape != [1, 3, 640, 640]
            or output_shape != [1, 6, 8400]
        ):
            raise RuntimeError(
                "Unexpected model shapes: %s -> %s"
                % (input_shape, output_shape)
            )

        self.rgb = None
        self.rgb_arrival = 0.0
        self.last_rgb_stamp = -1

        self.depths = deque(maxlen=12)
        self.camera_info = None

        self.result_pub = self.create_publisher(
            String,
            RESULT_TOPIC,
            10
        )

        self.preview_pub = self.create_publisher(
            Image,
            ANNOTATED_TOPIC,
            1
        )

        self.create_subscription(
            Image,
            COLOR_TOPIC,
            self.on_rgb,
            qos_profile_sensor_data
        )

        self.create_subscription(
            Image,
            DEPTH_TOPIC,
            self.on_depth,
            qos_profile_sensor_data
        )

        self.create_subscription(
            CameraInfo,
            INFO_TOPIC,
            self.on_info,
            qos_profile_sensor_data
        )

        self.create_timer(
            INFER_PERIOD_SEC,
            self.run_inference
        )

        self.get_logger().info(
            "YOLO + ASTRA S V2 started"
        )

        self.get_logger().warn(
            "Class ID mapping not verified. "
            "Depth is approximate."
        )

    def on_rgb(self, msg):
        self.rgb = msg
        self.rgb_arrival = time.monotonic()

    def on_depth(self, msg):
        self.depths.append((
            stamp_ns(msg.header),
            time.monotonic(),
            msg
        ))

    def on_info(self, msg):
        self.camera_info = msg

    def match_depth(self, rgb, now):
        if not self.depths:
            return None, None, "NO_DEPTH_RECEIVED", None

        rgb_stamp = stamp_ns(rgb.header)

        nearest = min(
            self.depths,
            key=lambda item: abs(item[0] - rgb_stamp)
        )

        depth_stamp, arrival, depth_msg = nearest

        diff_ms = abs(
            depth_stamp - rgb_stamp
        ) / 1e6

        age_ms = (
            now - arrival
        ) * 1000.0

        arrival_gap_ms = abs(
            arrival - self.rgb_arrival
        ) * 1000.0

        if age_ms > MAX_RECEIVE_AGE_MS:
            return None, diff_ms, "STALE_DEPTH", age_ms

        if diff_ms > MAX_TIME_DIFF_MS:
            return None, diff_ms, "TIMESTAMP_MISMATCH", age_ms

        if arrival_gap_ms > MAX_RECEIVE_GAP_MS:
            return None, diff_ms, "RECEIVE_TIME_MISMATCH", age_ms

        if (
            depth_msg.width != rgb.width
            or depth_msg.height != rgb.height
        ):
            return None, diff_ms, "RESOLUTION_MISMATCH", age_ms

        if (
            depth_msg.header.frame_id
            != rgb.header.frame_id
        ):
            return None, diff_ms, "FRAME_ID_MISMATCH", age_ms

        return depth_msg, diff_ms, None, age_ms

    def run_inference(self):
        rgb = self.rgb

        if rgb is None:
            return

        rgb_stamp = stamp_ns(rgb.header)

        if (
            rgb_stamp <= 0
            or rgb_stamp == self.last_rgb_stamp
        ):
            return

        self.last_rgb_stamp = rgb_stamp

        start = time.monotonic()
        rgb_age_ms = (
            start - self.rgb_arrival
        ) * 1000.0

        if rgb_age_ms > MAX_RECEIVE_AGE_MS:
            return

        depth_msg, diff_ms, reason, depth_age_ms = (
            self.match_depth(rgb, start)
        )

        try:
            frame = bgr_from_ros(rgb)

            tensor, ratio, left, top = letterbox(
                frame,
                640,
                640
            )

            inference_start = time.monotonic()

            outputs = self.engine.process(
                self.graph,
                {self.input_name: tensor}
            )

            inference_ms = (
                time.monotonic() - inference_start
            ) * 1000.0

            detections = decode(
                outputs[self.output_name],
                ratio,
                left,
                top,
                rgb.width,
                rgb.height
            )

            depth = None

            # Decode depth only when a matched frame exists
            # and YOLO has detections.
            if (
                depth_msg is not None
                and detections
            ):
                depth = depth_from_ros(depth_msg)

            for item in detections:
                if depth is None:
                    item.update({
                        "depth_status": "UNKNOWN",
                        "reason": reason or "NO_VALID_DEPTH_PAIR"
                    })
                else:
                    item.update(
                        sample_depth(
                            depth,
                            item,
                            self.camera_info
                        )
                    )

            output = {
                "state": (
                    "DETECTED"
                    if detections
                    else "NO_DETECTION"
                ),
                "class_mapping_verified": False,
                "rgb_stamp_ns": rgb_stamp,
                "depth_pair_valid": depth_msg is not None,
                "depth_pair_reason": reason,
                "depth_diff_ms": (
                    round(diff_ms, 2)
                    if diff_ms is not None
                    else None
                ),
                "rgb_receive_age_ms": round(
                    rgb_age_ms, 1
                ),
                "depth_receive_age_ms": (
                    round(depth_age_ms, 1)
                    if depth_age_ms is not None
                    else None
                ),
                "detections": detections,
                "inference_ms": round(
                    inference_ms, 1
                ),
                "total_ms": round(
                    (time.monotonic() - start) * 1000.0,
                    1
                )
            }

            # Avoid publishing a full annotated image
            # when nobody is subscribing to it.
            if self.preview_pub.get_subscription_count() > 0:
                self.publish_preview(
                    rgb,
                    frame,
                    detections
                )

        except Exception as exc:
            self.get_logger().error(str(exc))
            output = {
                "state": "ERROR",
                "error": str(exc)
            }

        msg = String()
        msg.data = json.dumps(
            output,
            ensure_ascii=False,
            allow_nan=False
        )

        self.result_pub.publish(msg)

    def publish_preview(self, rgb, frame, detections):
        image = frame.copy()

        for item in detections:
            x1, y1, x2, y2 = item["xyxy"]

            cv2.rectangle(
                image,
                (x1, y1),
                (x2, y2),
                (0, 255, 255),
                2
            )

            if item.get("depth_status") == "VALID":
                label = "C%d %.2f %.1fcm" % (
                    item["class_id"],
                    item["score"],
                    item["distance_cm"]
                )
            else:
                label = "C%d %.2f UNKNOWN" % (
                    item["class_id"],
                    item["score"]
                )

            cv2.putText(
                image,
                label,
                (x1, max(16, y1 - 4)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                (0, 0, 255),
                2
            )

        annotated = Image()
        annotated.header = rgb.header
        annotated.height = image.shape[0]
        annotated.width = image.shape[1]
        annotated.encoding = "bgr8"
        annotated.is_bigendian = 0
        annotated.step = annotated.width * 3
        annotated.data = np.ascontiguousarray(
            image
        ).tobytes()

        self.preview_pub.publish(annotated)


def main():
    rclpy.init()
    node = None

    try:
        node = FusionNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()

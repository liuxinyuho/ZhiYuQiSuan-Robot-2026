#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
from collections import deque

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from sensor_msgs.msg import Image


class RGBDPairCheck(Node):

    def __init__(self):

        super().__init__('rgbd_pair_check')

        self.rgb_queue = deque(maxlen=30)
        self.depth_queue = deque(maxlen=30)

        self.reported = set()
        self.count = 0
        self.done = False

        self.create_subscription(
            Image,
            '/camera/color/image_raw',
            self.rgb_callback,
            qos_profile_sensor_data
        )

        self.create_subscription(
            Image,
            '/camera/depth/image_raw',
            self.depth_callback,
            qos_profile_sensor_data
        )

        print("\n========== RGB-D PAIR CHECK ==========")
        print("Waiting for RGB and Depth frames...")

    def get_info(self, msg):

        stamp = (
            msg.header.stamp.sec * 1000000000
            + msg.header.stamp.nanosec
        )

        return {
            'stamp': stamp,
            'frame_id': msg.header.frame_id,
            'width': msg.width,
            'height': msg.height,
            'encoding': msg.encoding
        }

    def rgb_callback(self, msg):

        self.rgb_queue.append(self.get_info(msg))
        self.check_pair()

    def depth_callback(self, msg):

        self.depth_queue.append(self.get_info(msg))
        self.check_pair()

    def check_pair(self):

        if self.done:
            return

        if not self.rgb_queue or not self.depth_queue:
            return

        rgb = self.rgb_queue[-1]

        depth = min(
            self.depth_queue,
            key=lambda item: abs(
                item['stamp'] - rgb['stamp']
            )
        )

        key = (rgb['stamp'], depth['stamp'])

        if key in self.reported:
            return

        self.reported.add(key)

        diff_ms = abs(
            rgb['stamp'] - depth['stamp']
        ) / 1000000.0

        self.count += 1

        print("\n========== PAIR", self.count, "==========")

        print(
            "RGB:",
            rgb['width'],
            "x",
            rgb['height'],
            rgb['encoding']
        )

        print("RGB frame_id:", rgb['frame_id'])

        print(
            "Depth:",
            depth['width'],
            "x",
            depth['height'],
            depth['encoding']
        )

        print("Depth frame_id:", depth['frame_id'])

        print("Timestamp difference: %.3f ms" % diff_ms)

        print(
            "Same frame_id:",
            rgb['frame_id'] == depth['frame_id']
        )

        print(
            "Same resolution:",
            rgb['width'] == depth['width']
            and rgb['height'] == depth['height']
        )

        print(
            "Timestamp status:",
            "OK" if diff_ms <= 50 else "WARNING"
        )

        print("====================================")

        if self.count >= 10:
            self.done = True


def main():

    rclpy.init()

    node = RGBDPairCheck()

    deadline = time.monotonic() + 20

    try:

        while (
            rclpy.ok()
            and not node.done
            and time.monotonic() < deadline
        ):

            rclpy.spin_once(
                node,
                timeout_sec=0.2
            )

        print("\n========== TEST SUMMARY ==========")
        print("Valid pairs checked:", node.count)

    finally:

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
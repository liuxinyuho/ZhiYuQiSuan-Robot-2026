#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import time
import statistics

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class FlameXYZCollector(Node):

    def __init__(self):

        super().__init__('flame_xyz_collector')

        self.target_samples = 20
        self.samples = []
        self.seen_stamps = set()

        self.start_time = time.monotonic()

        self.sub = self.create_subscription(
            String,
            '/ai/fire_depth_result',
            self.callback,
            10
        )

        print("\n========== FLAME XYZ COLLECTION ==========")
        print("Topic: /ai/fire_depth_result")
        print("Target samples: 20")
        print("Waiting for valid flame XYZ...")
        print("===========================================\n")

    def callback(self, msg):

        if len(self.samples) >= self.target_samples:
            return

        try:
            data = json.loads(msg.data)
        except Exception:
            return

        stamp = data.get('rgb_stamp_ns')

        if stamp is not None and stamp in self.seen_stamps:
            return

        for item in data.get('detections', []):

            if item.get('class_name') != 'flame':
                continue

            if item.get('depth_status') != 'VALID':
                continue

            xyz = item.get('xyz_camera_m')

            if xyz is None or len(xyz) != 3:
                continue

            try:
                x, y, z = [float(v) for v in xyz]
                score = float(item.get('score', 0))
            except (ValueError, TypeError):
                continue

            if not all(
                v == v and abs(v) < 100
                for v in (x, y, z)
            ):
                continue

            if z <= 0:
                continue

            if stamp is not None:
                self.seen_stamps.add(stamp)

            sample = {
                'x': x,
                'y': y,
                'z': z,
                'score': score,
                'distance_cm': z * 100
            }

            self.samples.append(sample)

            index = len(self.samples)

            print(
                "[%02d/20] "
                "X=%+.3f m "
                "Y=%+.3f m "
                "Z=%.3f m "
                "Distance=%.1f cm "
                "Score=%.3f"
                % (
                    index,
                    x, y, z,
                    z * 100,
                    score
                )
            )

            break

    def print_summary(self):

        print("\n========== XYZ TEST SUMMARY ==========")

        print("Valid samples:", len(self.samples))

        if not self.samples:
            print("No valid XYZ data!")
            return

        for axis in ['x', 'y', 'z']:

            values = [
                s[axis] for s in self.samples
            ]

            print("\n%s AXIS" % axis.upper())

            print(
                "Mean: %.4f m"
                % statistics.mean(values)
            )

            print(
                "Median: %.4f m"
                % statistics.median(values)
            )

            print(
                "Min: %.4f m"
                % min(values)
            )

            print(
                "Max: %.4f m"
                % max(values)
            )

            print(
                "Std: %.4f m"
                % statistics.pstdev(values)
            )

            print(
                "Range: %.4f m"
                % (max(values) - min(values))
            )

        distances = [
            s['distance_cm']
            for s in self.samples
        ]

        print("\nDISTANCE")

        print(
            "Mean: %.2f cm"
            % statistics.mean(distances)
        )

        print(
            "Std: %.3f cm"
            % statistics.pstdev(distances)
        )

        print("\n========== COLLECTION FINISHED ==========")


def main():

    rclpy.init()

    node = FlameXYZCollector()

    try:

        timeout = 90

        while (
            len(node.samples) < node.target_samples
            and time.monotonic() - node.start_time < timeout
        ):

            rclpy.spin_once(
                node,
                timeout_sec=0.2
            )

    except KeyboardInterrupt:
        pass

    finally:

        node.print_summary()

        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
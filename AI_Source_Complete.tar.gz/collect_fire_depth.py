#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import math
import statistics

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


TOPIC = "/ai/fire_depth_result"
TARGET_SAMPLES = 20


def to_float(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


class FireDepthCollector(Node):

    def __init__(self):
        super().__init__("fire_depth_collector")

        self.count = 0
        self.records = []

        self.sub = self.create_subscription(
            String,
            TOPIC,
            self.callback,
            10
        )

        print("\n========== FIRE DEPTH TEST ==========")
        print("Topic:", TOPIC)
        print("Target samples:", TARGET_SAMPLES)
        print("Waiting for results...\n")

    def callback(self, msg):

        try:
            data = json.loads(msg.data)
        except Exception as e:
            print("JSON ERROR:", e)
            return

        detections = data.get("detections", [])

        detection = None

        if detections:
            detection = max(
                detections,
                key=lambda x: to_float(x.get("score")) or 0
            )

        if detection is not None:

            cid = detection.get("class_id")

            class_names = data.get("class_names", {})

            name = detection.get(
                "class_name",
                class_names.get(str(cid), "unknown")
            )

            score = to_float(detection.get("score"))

            depth_status = detection.get(
                "depth_status", "UNKNOWN"
            )

            distance = to_float(
                detection.get("distance_cm")
            )

            if distance is None:
                z = to_float(detection.get("z_m"))
                if z is not None:
                    distance = z * 100.0

        else:
            cid = None
            name = "NONE"
            score = None
            depth_status = "UNKNOWN"
            distance = None

        record = {
            "state": data.get("state"),
            "class_id": cid,
            "class_name": name,
            "score": score,
            "depth_status": depth_status,
            "distance_cm": distance,
            "depth_pair_valid": data.get(
                "depth_pair_valid"
            ),
            "depth_diff_ms": to_float(
                data.get("depth_diff_ms")
            ),
            "inference_ms": to_float(
                data.get("inference_ms")
            ),
            "total_ms": to_float(
                data.get("total_ms")
            )
        }

        self.records.append(record)
        self.count += 1

        print(
            "[%02d/%02d] state=%s class=%s "
            "score=%s depth=%s distance=%s cm "
            "pair=%s diff=%s ms total=%s ms"
            % (
                self.count,
                TARGET_SAMPLES,
                record["state"],
                record["class_name"],
                record["score"],
                record["depth_status"],
                record["distance_cm"],
                record["depth_pair_valid"],
                record["depth_diff_ms"],
                record["total_ms"]
            )
        )

    def summary(self):

        print("\n========== TEST SUMMARY ==========")

        detected = [
            x for x in self.records
            if x["state"] == "DETECTED"
        ]

        valid = [
            x["distance_cm"]
            for x in self.records
            if x["depth_status"] == "VALID"
            and x["distance_cm"] is not None
        ]

        print("Received:", len(self.records))
        print("Detected:", len(detected))
        print("Valid depth:", len(valid))

        if valid:

            print(
                "Distance median: %.2f cm"
                % statistics.median(valid)
            )

            print(
                "Distance mean: %.2f cm"
                % statistics.mean(valid)
            )

            print(
                "Distance min: %.2f cm"
                % min(valid)
            )

            print(
                "Distance max: %.2f cm"
                % max(valid)
            )

            print(
                "Distance range: %.2f cm"
                % (max(valid) - min(valid))
            )

            if len(valid) >= 2:
                print(
                    "Distance std: %.2f cm"
                    % statistics.stdev(valid)
                )

        else:
            print("WARNING: No valid depth measurements!")

        print("\n========== CHECK FINISHED ==========")


def main():

    rclpy.init()

    node = FireDepthCollector()

    try:
        while rclpy.ok() and node.count < TARGET_SAMPLES:
            rclpy.spin_once(
                node,
                timeout_sec=1.0
            )

    except KeyboardInterrupt:
        print("\nInterrupted.")

    finally:
        node.summary()
        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()

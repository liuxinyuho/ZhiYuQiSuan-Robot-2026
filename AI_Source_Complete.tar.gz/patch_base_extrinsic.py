from pathlib import Path
from datetime import datetime
import shutil
import sys

path = Path("sophon_astra_depth_fusion_v4.py")

if not path.exists():
    sys.exit("ERROR: V4 source file not found")

source = path.read_text()

def replace_once(old, new, name):
    global source

    count = source.count(old)

    if count != 1:
        raise RuntimeError(
            "%s: expected 1 match, found %d"
            % (name, count)
        )

    source = source.replace(old, new, 1)
    print("[OK] " + name)


# ==================================================
# 1. 外参配置
# ==================================================

replace_once(
'''CAMERA_MOUNT_DIRECTION = "FORWARD"
CAMERA_EXTRINSIC_CALIBRATED = False
''',
'''CAMERA_MOUNT_DIRECTION = "FORWARD"

# Robot base coordinate frame:
# X forward, Y left, Z up.
BASE_FRAME_ID = "base_footprint"

# Astra S optical coordinate frame.
CAMERA_OPTICAL_FRAME_ID = "camera_color_optical_frame"

# Camera origin expressed in base_footprint (meters).
CAMERA_TRANSLATION_BASE_CAMERA_M = (
    0.130,
    0.000,
    0.300
)

# Rotation from camera optical frame to base frame.
# Quaternion order: x, y, z, w.
CAMERA_ROTATION_BASE_CAMERA_OPTICAL_XYZW = (
    -0.5,
     0.5,
    -0.5,
     0.5
)

CAMERA_EXTRINSIC_CONFIGURED = True
CAMERA_TF_VERIFIED = True

# Installation measurements are approximate.
# Do not mark precision calibration as completed.
CAMERA_EXTRINSIC_CALIBRATED = False
''',
"camera extrinsic configuration"
)


# ==================================================
# 2. 相机坐标转换函数
# ==================================================

replace_once(
'''class FusionNode(Node):
''',
'''def camera_to_base(xyz_camera):
    """
    Convert camera optical XYZ into robot base XYZ.

    Camera optical:
        X right
        Y down
        Z forward

    Robot base:
        X forward
        Y left
        Z up
    """

    xc, yc, zc = [
        float(v) for v in xyz_camera
    ]

    qx, qy, qz, qw = (
        CAMERA_ROTATION_BASE_CAMERA_OPTICAL_XYZW
    )

    # Normalize quaternion.
    qnorm = (
        qx * qx
        + qy * qy
        + qz * qz
        + qw * qw
    ) ** 0.5

    if qnorm < 1e-12:
        raise ValueError("Invalid camera extrinsic quaternion")

    qx /= qnorm
    qy /= qnorm
    qz /= qnorm
    qw /= qnorm

    # Rotation matrix: camera optical -> base.
    rotation = np.array([
        [
            1 - 2 * (qy*qy + qz*qz),
            2 * (qx*qy - qz*qw),
            2 * (qx*qz + qy*qw)
        ],
        [
            2 * (qx*qy + qz*qw),
            1 - 2 * (qx*qx + qz*qz),
            2 * (qy*qz - qx*qw)
        ],
        [
            2 * (qx*qz - qy*qw),
            2 * (qy*qz + qx*qw),
            1 - 2 * (qx*qx + qy*qy)
        ]
    ], dtype=np.float64)

    translation = np.array(
        CAMERA_TRANSLATION_BASE_CAMERA_M,
        dtype=np.float64
    )

    point_camera = np.array(
        [xc, yc, zc],
        dtype=np.float64
    )

    point_base = (
        translation
        + rotation @ point_camera
    )

    return [
        round(float(point_base[0]), 3),
        round(float(point_base[1]), 3),
        round(float(point_base[2]), 3)
    ]


class FusionNode(Node):
''',
"camera to base transformation function"
)


# ==================================================
# 3. 检测结果增加底盘坐标
# ==================================================

replace_once(
'''            for item in detections:

                if depth is None:

                    item.update({
                        "depth_status": "UNKNOWN",
                        "reason": reason or "NO_VALID_DEPTH_PAIR"
                    })

                else:

                    item.update(
                        sample_depth(
                            depth,
                            item,
                            self.camera_info
                        )
                    )
''',
'''            for item in detections:

                if depth is None:

                    item.update({
                        "depth_status": "UNKNOWN",
                        "reason": reason or "NO_VALID_DEPTH_PAIR"
                    })

                else:

                    item.update(
                        sample_depth(
                            depth,
                            item,
                            self.camera_info
                        )
                    )

                # Convert valid camera XYZ into base XYZ.
                camera_xyz = item.get("xyz_camera_m")

                if (
                    item.get("depth_status") == "VALID"
                    and camera_xyz is not None
                ):

                    item["xyz_base_m"] = camera_to_base(
                        camera_xyz
                    )

                    item["xyz_base_frame_id"] = BASE_FRAME_ID

                    item["base_transform_status"] = "APPLIED"

                else:

                    item["xyz_base_frame_id"] = BASE_FRAME_ID

                    item["base_transform_status"] = "UNAVAILABLE"
''',
"detection base coordinate conversion"
)


# ==================================================
# 4. 更新 JSON 中的相机安装信息
# ==================================================

replace_once(
'''                "camera_mount": {
                    "direction": CAMERA_MOUNT_DIRECTION,
                    "extrinsic_calibrated": CAMERA_EXTRINSIC_CALIBRATED,
                    "base_link_transform_applied": False
                },
''',
'''                "camera_mount": {
                    "direction": CAMERA_MOUNT_DIRECTION,

                    "base_frame_id": BASE_FRAME_ID,

                    "camera_optical_frame_id":
                        CAMERA_OPTICAL_FRAME_ID,

                    "translation_base_camera_m":
                        list(CAMERA_TRANSLATION_BASE_CAMERA_M),

                    "rotation_base_camera_optical_xyzw":
                        list(CAMERA_ROTATION_BASE_CAMERA_OPTICAL_XYZW),

                    "extrinsic_configured":
                        CAMERA_EXTRINSIC_CONFIGURED,

                    "tf_verified":
                        CAMERA_TF_VERIFIED,

                    "extrinsic_calibrated":
                        CAMERA_EXTRINSIC_CALIBRATED,

                    "base_transform_applied": True,

                    # Retained for compatibility with earlier logs.
                    "base_link_transform_applied": True
                },
''',
"camera mount JSON metadata"
)


# ==================================================
# 5. 全部修改成功后再写入文件
# ==================================================

backup = path.with_name(
    path.name
    + ".bak_"
    + datetime.now().strftime("%Y%m%d_%H%M%S")
)

shutil.copy2(path, backup)

path.write_text(source)

print()
print("========== PATCH FINISHED ==========")
print("Original backup:", backup)
print("Modified file:", path)
print("Base frame:", "base_footprint")
print("Extrinsic configured:", True)
print("Extrinsic calibrated:", False)
print("====================================")

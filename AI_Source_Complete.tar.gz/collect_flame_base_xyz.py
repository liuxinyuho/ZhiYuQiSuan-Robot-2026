#!/usr/bin/env python3

import json
import time
import numpy as np
import rclpy

from rclpy.node import Node
from std_msgs.msg import String


TOPIC = "/ai/fire_depth_result"
TARGET_SAMPLES = 20
TIMEOUT_SEC = 90


class FlameBaseCollector(Node):

    def __init__(self):
        super().__init__("flame_base_xyz_collector")

        self.samples = []

        self.sub = self.create_subscription(
            String,
            TOPIC,
            self.callback,
            10
        )

    def callback(self, msg):

        try:
            data = json.loads(msg.data)

            if data.get("state") != "DETECTED":
                return

            for item in data.get("detections", []):

                if item.get("class_name") != "flame":
                    continue

                if item.get("depth_status") != "VALID":
                    continue

                if item.get("base_transform_status") != "APPLIED":
                    continue

                xyz = item.get("xyz_base_m")

                if not isinstance(xyz, list) or len(xyz) != 3:
                    continue

                if len(self.samples) >= TARGET_SAMPLES:
                    return

                x, y, z = map(float, xyz)

                self.samples.append([x, y, z])

                index = len(self.samples)

                print(
                    "[%02d/%02d] "
                    "X=%+.3f m "
                    "Y=%+.3f m "
                    "Z=%+.3f m "
                    "Distance=%.1f cm"
                    % (
                        index,
                        TARGET_SAMPLES,
                        x, y, z,
                        item.get("distance_cm", 0)
                    ),
                    flush=True
                )

                break

        except Exception as e:
            print("ERROR:", e)


def main():

    print("\n========== FLAME BASE XYZ COLLECTION ==========")
    print("Topic:", TOPIC)
    print("Target samples:", TARGET_SAMPLES)
    print("Waiting for valid base XYZ...")
    print("===============================================\n")

    rclpy.init()

    node = FlameBaseCollector()

    start = time.monotonic()

    try:

        while (
            len(node.samples) < TARGET_SAMPLES
            and time.monotonic() - start < TIMEOUT_SEC
        ):

            rclpy.spin_once(
                node,
                timeout_sec=0.2
            )

    finally:

        node.destroy_node()
        rclpy.shutdown()

    if not node.samples:
        print("ERROR: No valid base XYZ received.")
        return

    arr = np.array(node.samples)

    names = ["X forward", "Y left", "Z up"]

    print("\n========== BASE XYZ SUMMARY ==========")
    print("Valid samples:", len(arr))

    for i, name in enumerate(names):

        values = arr[:, i]

        print("\n" + name)
        print("Mean: %.4f m" % np.mean(values))
        print("Median: %.4f m" % np.median(values))
        print("Min: %.4f m" % np.min(values))
        print("Max: %.4f m" % np.max(values))
        print("Std: %.4f m" % np.std(values))

    print("\n========== COLLECTION FINISHED ==========")


if __name__ == "__main__":
    main()

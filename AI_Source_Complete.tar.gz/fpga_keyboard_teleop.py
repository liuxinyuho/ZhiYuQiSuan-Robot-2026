
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import sys
import time
import select
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class FPGAKeyboardTeleop(Node):

    def __init__(self):
        super().__init__('fpga_keyboard_teleop')

        self.publisher = self.create_publisher(
            String,
            '/fpga/command',
            10
        )

        self.get_logger().info(
            'Keyboard teleop started'
        )

    def publish_command(self, data):

        msg = String()
        msg.data = json.dumps(
            data,
            separators=(',', ':')
        )

        self.publisher.publish(msg)

    def velocity(self, vx, vy, wz):

        self.publish_command({
            'cmd': 'VELOCITY',
            'vx': vx,
            'vy': vy,
            'wz': wz
        })

    def stop(self):

        self.publish_command({
            'cmd': 'STOP'
        })


def main():

    rclpy.init()

    node = FPGAKeyboardTeleop()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)

    # 初始低速参数
    SPEED = 2
    ROTATE_SPEED = 1

    # 按键映射
    key_map = {
        'w': ( SPEED, 0, 0),  # 前进
        's': (-SPEED, 0, 0),  # 后退
        'a': (0,  SPEED, 0),  # 左移
        'd': (0, -SPEED, 0),  # 右移
        'q': (0, 0,  ROTATE_SPEED),  # 左转
        'e': (0, 0, -ROTATE_SPEED)   # 右转
    }

    current = (0, 0, 0)
    last_key_time = 0.0
    last_publish_time = 0.0
    was_moving = False

    # 按键重复超时，避免按键失联后持续运动
    KEY_TIMEOUT = 0.65

    try:

        tty.setcbreak(fd)

        print('\n========== FPGA KEYBOARD CONTROL ==========')
        print('W : Forward')
        print('S : Backward')
        print('A : Left')
        print('D : Right')
        print('Q : Rotate Left')
        print('E : Rotate Right')
        print('SPACE / X : STOP')
        print('CTRL+C : Exit')
        print('============================================\n')

        # 等待串口桥接节点订阅
        for _ in range(30):

            rclpy.spin_once(
                node,
                timeout_sec=0.05
            )

            if node.publisher.get_subscription_count() > 0:
                break

            time.sleep(0.05)

        if node.publisher.get_subscription_count() == 0:

            print('WARNING: FPGA bridge not connected')

        else:

            print('FPGA bridge connected')

        node.stop()

        while rclpy.ok():

            rclpy.spin_once(
                node,
                timeout_sec=0.0
            )

            ready, _, _ = select.select(
                [sys.stdin],
                [],
                [],
                0.02
            )

            if ready:

                key = sys.stdin.read(1).lower()

                if key in key_map:

                    current = key_map[key]
                    last_key_time = time.monotonic()

                elif key in (' ', 'x'):

                    current = (0, 0, 0)
                    last_key_time = 0.0

                    node.stop()
                    was_moving = False

                    print('STOP')

                elif key == '\x03':

                    break

            now = time.monotonic()

            # 长时间没有收到按键重复信号，自动停止
            if (
                current != (0, 0, 0)
                and now - last_key_time > KEY_TIMEOUT
            ):

                current = (0, 0, 0)

            # 10Hz 发送运动指令
            if now - last_publish_time >= 0.1:

                if current != (0, 0, 0):

                    vx, vy, wz = current

                    node.velocity(
                        vx,
                        vy,
                        wz
                    )

                    was_moving = True

                elif was_moving:

                    node.stop()
                    was_moving = False

                last_publish_time = now

    except KeyboardInterrupt:

        pass

    finally:

        # 退出前发送停止指令
        node.stop()

        time.sleep(0.15)

        termios.tcsetattr(
            fd,
            termios.TCSADRAIN,
            old_settings
        )

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()

        print('\nFPGA KEYBOARD CONTROL EXITED')


if __name__ == '__main__':
    main()

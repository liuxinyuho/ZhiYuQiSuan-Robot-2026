import json
import time
import rclpy

from rclpy.node import Node
from std_msgs.msg import String


class RealtimeDistance(Node):

    def __init__(self):
        super().__init__('realtime_distance_viewer')

        self.sub = self.create_subscription(
            String,
            '/ai/fire_depth_result',
            self.callback,
            10
        )

        print("\n========== YOLO REALTIME DISTANCE ==========")
        print("Waiting for AI detection...\n")

    def callback(self, msg):

        try:
            data = json.loads(msg.data)
        except Exception as e:
            print("JSON ERROR:", e)
            return

        state = data.get('state', 'UNKNOWN')
        detections = data.get('detections', [])

        if isinstance(detections, dict):
            detections = [detections]

        now = time.strftime('%H:%M:%S')

        if not detections:

            print(
                "[%s] STATE=%s | No valid detection"
                % (now, state),
                flush=True
            )
            return

        names = data.get('class_names', {})

        for det in detections:

            class_id = det.get('class_id', -1)

            label = names.get(
                str(class_id),
                'class_' + str(class_id)
            )

            score = float(det.get('score', 0))

            depth_status = str(
                det.get('depth_status', 'UNKNOWN')
            ).upper()

            distance = det.get('distance_cm')

            if distance is None:

                z = det.get('z_m')

                if z is not None:
                    distance = float(z) * 100.0

            if distance is not None and depth_status in (
                'VALID', 'OK'
            ):

                print(
                    "[%s] %-12s CONF=%.1f%% DISTANCE=%.2f cm"
                    % (
                        now,
                        label,
                        score * 100,
                        float(distance)
                    ),
                    flush=True
                )

            else:

                print(
                    "[%s] %-12s CONF=%.1f%% DEPTH INVALID"
                    % (now, label, score * 100),
                    flush=True
                )


def main():

    rclpy.init()

    node = RealtimeDistance()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        print("\nDistance viewer stopped.")

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import math
import time

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from geometry_msgs.msg import PointStamped


class FlameTargetLocalizer(Node):

    def __init__(self):
        super().__init__('flame_target_localizer')

        # ==========================================
        # 1. 参数配置
        # ==========================================

        self.input_topic = self.declare_parameter(
            'input_topic',
            '/ai/fire_depth_result'
        ).value

        self.point_topic = self.declare_parameter(
            'point_topic',
            '/ai/flame_target_base'
        ).value

        self.status_topic = self.declare_parameter(
            'status_topic',
            '/ai/flame_target_status'
        ).value

        self.target_class = str(
            self.declare_parameter(
                'target_class', 'flame'
            ).value
        ).lower()

        self.min_confidence = float(
            self.declare_parameter(
                'min_confidence', 0.50
            ).value
        )

        self.ema_alpha = float(
            self.declare_parameter(
                'ema_alpha', 0.45
            ).value
        )

        self.ema_alpha = max(
            0.01, min(1.0, self.ema_alpha)
        )

        self.base_frame = str(
            self.declare_parameter(
                'base_frame', 'base_footprint'
            ).value
        )

        self.stale_timeout = float(
            self.declare_parameter(
                'stale_timeout_sec', 0.7
            ).value
        )

        # ==========================================
        # 2. 发布器
        # ==========================================

        self.point_pub = self.create_publisher(
            PointStamped,
            self.point_topic,
            10
        )

        self.status_pub = self.create_publisher(
            String,
            self.status_topic,
            10
        )

        # ==========================================
        # 3. 订阅 V5 视觉结果
        # ==========================================

        self.subscription = self.create_subscription(
            String,
            self.input_topic,
            self.result_callback,
            10
        )

        # ==========================================
        # 4. 滤波与状态
        # ==========================================

        self.filtered_xyz = None

        self.valid_count = 0

        self.last_message_time = None

        self.stale_reported = False

        # 检查消息是否超时
        self.timer = self.create_timer(
            0.2,
            self.check_stale
        )

        self.get_logger().info(
            '======================================'
        )
        self.get_logger().info(
            'FLAME TARGET LOCALIZER STARTED'
        )
        self.get_logger().info(
            'Input: ' + self.input_topic
        )
        self.get_logger().info(
            'Point: ' + self.point_topic
        )
        self.get_logger().info(
            'Status: ' + self.status_topic
        )
        self.get_logger().info(
            'Base frame: ' + self.base_frame
        )
        self.get_logger().info(
            'EMA alpha: %.2f' % self.ema_alpha
        )
        self.get_logger().info(
            '======================================'
        )

    # ==============================================
    # JSON 状态发布
    # ==============================================

    def publish_status(self, data):

        msg = String()

        msg.data = json.dumps(
            data,
            ensure_ascii=False
        )

        self.status_pub.publish(msg)

    # ==============================================
    # 无效目标处理
    # ==============================================

    def invalid_target(self, state, reason):

        self.filtered_xyz = None

        self.publish_status({
            'state': state,
            'reason': reason,
            'frame_id': self.base_frame,
            'target_class': self.target_class
        })

    # ==============================================
    # 实时视觉结果回调
    # ==============================================

    def result_callback(self, msg):

        self.last_message_time = time.monotonic()
        self.stale_reported = False

        # 解析 JSON
        try:
            data = json.loads(msg.data)

        except Exception as e:

            self.invalid_target(
                'JSON_ERROR',
                str(e)
            )
            return

        if not isinstance(data, dict):

            self.invalid_target(
                'JSON_ERROR',
                'Invalid JSON structure'
            )
            return

        # ==========================================
        # 1. 检查深度配对
        # ==========================================

        if data.get('depth_pair_valid') is not True:

            self.invalid_target(
                'DEPTH_INVALID',
                str(data.get('depth_pair_reason'))
            )
            return

        if data.get('state') != 'DETECTED':

            self.invalid_target(
                str(data.get('state', 'NO_DETECTION')),
                'No valid detection'
            )
            return

        # ==========================================
        # 2. 检查外参状态
        # ==========================================

        mount = data.get('camera_mount', {})

        if not isinstance(mount, dict):

            self.invalid_target(
                'EXTRINSIC_ERROR',
                'camera_mount missing'
            )
            return

        if mount.get('base_transform_applied') is not True:

            self.invalid_target(
                'EXTRINSIC_ERROR',
                'Base transform not applied'
            )
            return

        mount_frame = mount.get('base_frame_id')

        if mount_frame and mount_frame != self.base_frame:

            self.invalid_target(
                'FRAME_MISMATCH',
                'Unexpected base frame: ' + str(mount_frame)
            )
            return

        # ==========================================
        # 3. 获取火焰检测结果
        # ==========================================

        detections = data.get('detections', [])

        if not isinstance(detections, list):

            self.invalid_target(
                'DETECTION_ERROR',
                'detections is not a list'
            )
            return

        candidates = []

        failure_reason = 'NO_FLAME_DETECTION'

        for item in detections:

            if not isinstance(item, dict):
                continue

            class_name = str(
                item.get('class_name', '')
            ).lower()

            # 只处理 flame
            if class_name != self.target_class:
                continue

            try:
                confidence = float(
                    item.get('score', 0.0)
                )
            except (TypeError, ValueError):
                continue

            if confidence < self.min_confidence:

                failure_reason = 'LOW_CONFIDENCE'
                continue

            # 检查深度
            if item.get('depth_status') != 'VALID':

                failure_reason = 'DEPTH_INVALID'
                continue

            # 必须已经转换到机器人底盘坐标系
            if item.get('base_transform_status') != 'APPLIED':

                failure_reason = 'BASE_TRANSFORM_NOT_APPLIED'
                continue

            xyz = item.get('xyz_base_m')

            if not isinstance(xyz, (list, tuple)) or len(xyz) != 3:

                failure_reason = 'BASE_XYZ_MISSING'
                continue

            try:
                xyz = [
                    float(xyz[0]),
                    float(xyz[1]),
                    float(xyz[2])
                ]

            except (TypeError, ValueError):

                failure_reason = 'BASE_XYZ_INVALID'
                continue

            if not all(math.isfinite(v) for v in xyz):

                failure_reason = 'BASE_XYZ_INVALID'
                continue

            frame_id = item.get(
                'xyz_base_frame_id',
                mount.get('base_frame_id', '')
            )

            if frame_id != self.base_frame:

                failure_reason = 'FRAME_MISMATCH'
                continue

            candidates.append({
                'item': item,
                'xyz': xyz,
                'score': confidence
            })

        # ==========================================
        # 4. 没有有效火焰目标
        # ==========================================

        if not candidates:

            self.invalid_target(
                'NO_VALID_TARGET',
                failure_reason
            )
            return

        # 多个目标时选择置信度最高的
        target = max(
            candidates,
            key=lambda x: x['score']
        )

        item = target['item']

        raw_xyz = target['xyz']

        confidence = target['score']

        # ==========================================
        # 5. XYZ 指数移动平均滤波
        # ==========================================

        if self.filtered_xyz is None:

            self.filtered_xyz = raw_xyz.copy()

        else:

            alpha = self.ema_alpha

            self.filtered_xyz = [

                alpha * raw_xyz[i]
                + (1.0 - alpha) * self.filtered_xyz[i]

                for i in range(3)
            ]

        x, y, z = self.filtered_xyz

        # ==========================================
        # 6. 发布机器人坐标系 XYZ
        # ==========================================

        point_msg = PointStamped()

        point_msg.header.stamp = (
            self.get_clock().now().to_msg()
        )

        point_msg.header.frame_id = self.base_frame

        point_msg.point.x = float(x)
        point_msg.point.y = float(y)
        point_msg.point.z = float(z)

        self.point_pub.publish(point_msg)

        # ==========================================
        # 7. 发布完整状态信息
        # ==========================================

        camera_xyz = item.get(
            'xyz_camera_m',
            None
        )

        status = {

            'state': 'TRACKING',

            'class_name': self.target_class,

            'class_id': item.get('class_id'),

            'confidence': confidence,

            'depth_status': 'VALID',

            'depth_pair_valid': True,

            'frame_id': self.base_frame,

            'camera_frame_id': data.get(
                'camera_frame_id'
            ),

            'camera_xyz_m': camera_xyz,

            'raw_xyz_base_m': raw_xyz,

            'filtered_xyz_base_m': [
                round(x, 5),
                round(y, 5),
                round(z, 5)
            ],

            'forward_m': round(x, 5),

            'left_m': round(y, 5),

            'up_m': round(z, 5),

            'horizontal_range_m': round(
                math.sqrt(x*x + y*y), 5
            ),

            'camera_distance_cm': item.get(
                'distance_cm'
            ),

            'filter': 'EMA',

            'extrinsic_configured': mount.get(
                'extrinsic_configured'
            ),

            'tf_verified': mount.get(
                'tf_verified'
            ),

            'extrinsic_calibrated': mount.get(
                'extrinsic_calibrated'
            ),

            'base_transform_applied': True

        }

        self.publish_status(status)

        # ==========================================
        # 8. 控制台调试输出
        # ==========================================

        self.valid_count += 1

        if self.valid_count == 1 or self.valid_count % 10 == 0:

            self.get_logger().info(
                'FLAME XYZ: X=%.3f Y=%.3f Z=%.3f '
                'Confidence=%.3f'
                % (x, y, z, confidence)
            )

            if mount.get('extrinsic_calibrated') is False:

                self.get_logger().warning(
                    'Extrinsic calibration flag is FALSE. '
                    'Using V5 existing base XYZ without '
                    'applying another transform.'
                )

    # ==============================================
    # 9. 消息超时检查
    # ==============================================

    def check_stale(self):

        if self.last_message_time is None:
            return

        elapsed = (
            time.monotonic() - self.last_message_time
        )

        if elapsed > self.stale_timeout:

            if not self.stale_reported:

                self.filtered_xyz = None

                self.publish_status({

                    'state': 'STALE',

                    'reason': 'Vision message timeout',

                    'frame_id': self.base_frame

                })

                self.get_logger().warning(
                    'Vision data timeout!'
                )

                self.stale_reported = True


def main(args=None):

    rclpy.init(args=args)

    node = FlameTargetLocalizer()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        node.get_logger().info(
            'Flame localizer stopped.'
        )

    finally:

        node.destroy_node()

        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':

    main()
